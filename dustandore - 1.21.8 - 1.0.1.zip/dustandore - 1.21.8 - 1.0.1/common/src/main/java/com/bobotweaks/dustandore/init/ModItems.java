package com.bobotweaks.dustandore.init;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;

public class ModItems {
	public static Item COPPER_DUST;
	public static Item IRON_DUST;
	public static Item GOLD_DUST;
	public static Item IRON_CRUSHING_HAMMER;
	public static Item COPPER_CRUSHING_HAMMER;
	public static Item NETHERITE_CRUSHING_HAMMER;
	public static Item GOLDEN_CRUSHING_HAMMER;
	public static Item DIAMOND_CRUSHING_HAMMER;
	public static Item ZINC_DUST;
}