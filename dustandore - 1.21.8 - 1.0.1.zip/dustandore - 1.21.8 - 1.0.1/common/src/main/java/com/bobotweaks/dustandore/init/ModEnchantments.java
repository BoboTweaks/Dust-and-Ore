package com.bobotweaks.dustandore.init;

import net.minecraft.resources.ResourceLocation;

public class ModEnchantments {
    public static final ResourceLocation ORE_SHATTER_RL = ResourceLocation.fromNamespaceAndPath("dustandore",
            "ore_shatter");
}